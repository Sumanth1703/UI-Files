var URL = "http://162.17.231.114:121/SpinoService.svc/GetData";

var app = angular.module("myApp", []);
app.controller("myCtrl", function ($scope, $http) {

//alert("inside ctrl")


var data = '{"userid": "1"}';

    $http({
            url: URL
            , method: "POST"
            , data: data
            , dataType: 'json'
            , headers: {
                "Content-Type": "application/json ; charset=utf-8"
            }
        }).success(function (data) {
        
		//alert(a.length);
			var a = $scope.PostDataResponse = data.GetDataResult;
			var index = a.length;
			var arr = [];
			var b = [];
			for(x=0; x<a.length; x++)
			{
				arr[x] = (a[x].Parent_Menu_Item);
				if(arr[x] == b)
				{
					b[x]=arr[x];
				}
				else
					alert(b);
				console.log(arr[x]);
			}
			alert(arr);
        })
        .error(function (data) {
               alert("inside error");
            $scope.PostDataResponse = "Data: " + data

        })
		
	

});



/* //var data = '{"userid": "1"}';
var app = angular.module('myApp', []);

app.controller("myCtrl", function ($scope, $http) {
	var data = '{"userid": "1"}';
    $http.post("http://162.17.231.114:121/SpinoService.svc/GetData",data).then(function (data) {
      $scope.PostDataResponse = data;
      //console.log(data);
    });
}); */