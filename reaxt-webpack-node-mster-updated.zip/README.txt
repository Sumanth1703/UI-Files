Instructions to add a Page:

1. Downloaded Clone Pack into my local drive, and then I have followed the instructions by installing the MongoDB into my local machine.
2. I have setup the mongoDB directory to run the mongo server. Now to develop the required page I have installed Node modules.
3. I have created two pages in Compoenents i have created ProductList and in Containers folder I have created Product page, as per requirements I have added css file in Css folder.
4. Now the final step to deploy the pages started Node Server to run the output.