module.exports = {
  DB_TYPES: {
    MONGO: 'MONGO',
    POSTGRES: 'POSTGRES',
    NONE: 'NONE'
  }
};

