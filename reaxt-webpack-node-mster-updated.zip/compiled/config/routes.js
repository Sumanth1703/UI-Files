'use strict';

var _topics = require('../controllers/topics');

var _topics2 = _interopRequireDefault(_topics);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var passport = require('passport'); /**
                                     * Routes for express app
                                     */

var users = require('../controllers/users');

module.exports = function (app) {
  // user routes
  app.post('/login', users.postLogin);
  app.post('/signup', users.postSignUp);
  app.post('/logout', users.postLogout);

  // google auth
  // Redirect the user to Google for authentication. When complete, Google
  // will redirect the user back to the application at
  // /auth/google/return
  // Authentication with google requires an additional scope param, for more info go
  // here https://developers.google.com/identity/protocols/OpenIDConnect#scope-param
  app.get('/auth/google', passport.authenticate('google', { scope: ['https://www.googleapis.com/auth/userinfo.profile', 'https://www.googleapis.com/auth/userinfo.email'] }));

  // Google will redirect the user to this URL after authentication. Finish the
  // process by verifying the assertion. If valid, the user will be logged in.
  // Otherwise, the authentication has failed.
  app.get('/auth/google/callback', passport.authenticate('google', {
    successRedirect: '/',
    failureRedirect: '/login'
  }));

  // topic routes
  app.get('/topic', _topics2.default.all);

  app.post('/topic/:id', function (req, res) {
    _topics2.default.add(req, res);
  });

  app.put('/topic/:id', function (req, res) {
    _topics2.default.update(req, res);
  });

  app.delete('/topic/:id', function (req, res) {
    _topics2.default.remove(req, res);
  });
};